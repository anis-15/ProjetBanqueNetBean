/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InitialisationEntity;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import session.CompteBancaireManager;
import session.UtilisateurManager;

/**
 *
 * @author a.djadour
 */
@Singleton
@Startup
@LocalBean
public class InitBean {

    @EJB
    private CompteBancaireManager compteBancaireManager;

    @EJB
    private UtilisateurManager utilisateurManager;
    
    @PostConstruct
    public void initBD() {
        System.out.println("#### -----------Creation des utilisateurs et des comptes bancaires ---------------------- ###");
        try {
          utilisateurManager.creerUtilisateurTest();
          compteBancaireManager.creerComptesTest();
        } catch (Exception e) {
            System.out.print("errur lors de la création des données " + e);
        }


    }
            
            
    

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
