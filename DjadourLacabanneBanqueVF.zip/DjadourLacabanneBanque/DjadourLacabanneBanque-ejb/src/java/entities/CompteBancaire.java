/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.djadour
 */
@Entity
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CompteBancaire.findAll", query = "SELECT c FROM CompteBancaire c"),
    @NamedQuery(name = "CompteBancaire .findByCommpteId", query = "SELECT c FROM CompteBancaire  c WHERE c.compteId = :compteId"),
    @NamedQuery(name = "CompteBancaire .findByName", query = "SELECT c FROM CompteBancaire  c WHERE c.nom = :nom"),
    @NamedQuery(name = "CompteBancaire .findBySolde", query = "SELECT c FROM CompteBancaire  c WHERE c.solde = :solde"),
    @NamedQuery(name = "CompteBancaire .findByAc", query = "SELECT c FROM CompteBancaire  c WHERE c.compteActif = :compteActif"),
    @NamedQuery(name = "CompteBancaire .findByUserId", query = "SELECT c FROM CompteBancaire c WHERE c.userId = :userId and c.compteActif = :compteActif")
})

   
        

public class CompteBancaire implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long compteId;
    private String nom;
    private int solde;
    private long userId;
    private boolean compteActif;

    public long getUserId() {
        return userId;
    }

    public boolean isCompteActif() {
        return compteActif;
    }

    public void setCompteActif(boolean compteActif) {
        this.compteActif = compteActif;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public CompteBancaire() {
    }
    
    
    
     public CompteBancaire (String nom, int solde, long userId, boolean compteActif){
        this.nom = nom;
        this.solde = solde;
        this.userId = userId;
        this.compteActif = compteActif;
    }
     public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getSolde() {
        return solde;
    }

    public void setSolde(int solde) {
        this.solde = solde;
    }
    
     public void deposer(int depot){
        solde += depot;
    }
    
    public int retirer(int depot){
        if(depot <= solde){
            solde-= depot;
            return depot;
        }
        
        else {
            return 0;
        }
        
    }
    
    public Long getCompteId() {
        return compteId;
    }

    public void setCompteId(Long compteId) {
        this.compteId = compteId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (compteId != null ? compteId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CompteBancaire)) {
            return false;
        }
        CompteBancaire other = (CompteBancaire) object;
        if ((this.compteId == null && other.compteId != null) || (this.compteId != null && !this.compteId.equals(other.compteId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.CompteBancaire[ compteId=" + compteId + " ]";
    }
    
}
