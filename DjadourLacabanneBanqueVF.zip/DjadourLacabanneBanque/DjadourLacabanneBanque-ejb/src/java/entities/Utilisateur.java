/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.djadour
 */
@Entity
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Utilisateur.findAll", query = "SELECT u FROM Utilisateur u"),
    @NamedQuery(name = "Utilisateur.findByRoleType", query = "SELECT u FROM Utilisateur u WHERE u.roleType = :roleType"),
    @NamedQuery(name = "Utilisateur.findByName", query = "SELECT u FROM Utilisateur  u WHERE u.nom = :nom"),
    @NamedQuery(name = "Utilisateur.findByPassword", query = "SELECT u FROM Utilisateur  u WHERE u.password = :password"),
    @NamedQuery(name = "Utilisateur.findByUtilisateurId", query = "SELECT u FROM Utilisateur  u WHERE u.id = :id"),
    @NamedQuery(name = "Utilisateur.findByNomUtilisateur", query = "SELECT u FROM Utilisateur  u WHERE u.nomUtilisateur = :nomUtilisateur"),
    @NamedQuery(name = "Utilisateur.findByAc", query = "SELECT u FROM Utilisateur  u WHERE u.utilisateurActif = :utilisateurActif"),
    @NamedQuery(name = "Utilisateur.findByAcR", query = "SELECT u FROM Utilisateur  u WHERE u.utilisateurActif = :utilisateurActif and u.roleType = :roleType"),
    @NamedQuery(name = "Utilisateur.findByUP", query = "SELECT u FROM Utilisateur  u WHERE u.nomUtilisateur = :nomUtilisateur and u.password = :password")
        
})
public class Utilisateur implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String nom;
    private String nomUtilisateur;
    private String roleType;
    private String password;
    private boolean utilisateurActif;
    
    
  

    public Utilisateur  () {
        
    }

    public boolean isUtilisateurActif() {
        return utilisateurActif;
    }

    public void setUtilisateurActif(boolean utilisateurActif) {
        this.utilisateurActif = utilisateurActif;
    }
    
    public Utilisateur (String nom, String nomUtilisateur, String password, String roleType, boolean utilisateurActif){
        this.nom = nom;
        this.nomUtilisateur = nomUtilisateur;
        this.password = password;
        this.roleType = roleType;
        this.utilisateurActif = utilisateurActif;
    }
    
    
    public String getRoleType() {
        return roleType;
    }

    public void setRoleType(String role) {
        this.roleType = role;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String npm) {
        this.nom = npm;
    }

    public String getNomUtilisateur() {
        return nomUtilisateur;
    }

    public void setNomUtilisateur(String nomUtilisateur) {
        this.nomUtilisateur = nomUtilisateur;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
 

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Utilisateur)) {
            return false;
        }
        Utilisateur other = (Utilisateur) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Utilisateur[ id=" + id + " ]";
    }
    
}
