/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import entities.OperationCompte;
import java.util.List;

/**
 *
 * @author a.djadour
 */
@Stateless
@LocalBean
public class OperationManager {

    @PersistenceContext(unitName = "DjadourLacabanneBanque-ejbPU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }
    public void creerOperation(OperationCompte o) {
        em.persist(o);
    }
    
    public List<OperationCompte> getAllOperation (){
        
        Query query = em.createNamedQuery("OperationCompte.findAll");  
        return query.getResultList();  
        
       }
    
      public OperationCompte getOperation (long id){
        return em.find(OperationCompte.class, id);
    }
      
      public List<OperationCompte> getLisOperationBycompteId(Long compteId) {
          Query query = em.createNamedQuery("OperationCompte.findByCompteId");  
          query.setParameter("compteId", compteId);  
          return  query.getResultList();  
      }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
