/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entities.Utilisateur;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author a.djadour
 */
@Stateless
@LocalBean
public class UtilisateurManager {

    @PersistenceContext(unitName = "DjadourLacabanneBanque-ejbPU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }

    public void creerUtilisateur(Utilisateur u){
        em.persist(u);
    }
    
    public Utilisateur update(Utilisateur u){
        return em.merge(u);
        
    }
    
    public void creerUtilisateurTest(){
        creerUtilisateur(new Utilisateur("Victor Lacabanne","v.lacabanne","lacabe","banquier", true));
        creerUtilisateur(new Utilisateur("Anis Djadour","a.djadour","djanis","client", true ));
        creerUtilisateur(new Utilisateur("James","j.james","jjames","client", true));
    }
    
   public List<Utilisateur> getAllUtilisateurs (){
        
        Query query = em.createNamedQuery("Utilisateur.findAll");  
        return query.getResultList();  
        
       }
   
    public Utilisateur getUtilisateurByUserId(String userId){
        Query query = em.createNamedQuery("Utilisateur.findByNomUtilisateur");  
        query.setParameter("utilisateur", "" + userId);  
        return (Utilisateur) query.getSingleResult();  
    }
    
    public Utilisateur getUtilisateur (long id){
        return em.find(Utilisateur.class, id);
    }
    
    public List<Utilisateur> getUtilisateurByRole(String role){
        Query query = em.createNamedQuery("Utilisateur.findByRoleType");  
        query.setParameter("roleType", role);  
        return  query.getResultList();  
        
    }
    
      public List<Utilisateur> getUtilisateurByAc(boolean ac){
        Query query = em.createNamedQuery("Utilisateur.findByAc");  
        query.setParameter("utilisateurActif", ac);  
        return  query.getResultList();  
        
    }
    
    public List <Utilisateur> getUtilisateurByNP(String nomUtilisateur, String password){
        Query query = em.createNamedQuery("Utilisateur.findByUP");
        query.setParameter("nomUtilisateur", nomUtilisateur);
        query.setParameter("password", password);
        
        return query.getResultList();
    }
     public List <Utilisateur> getUtilisateurByAcR(String roleType, boolean ac){
        Query query = em.createNamedQuery("Utilisateur.findByAcR");
        query.setParameter("roleType", roleType);
        query.setParameter("utilisateurActif", ac);
        
        return query.getResultList();
    }
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
