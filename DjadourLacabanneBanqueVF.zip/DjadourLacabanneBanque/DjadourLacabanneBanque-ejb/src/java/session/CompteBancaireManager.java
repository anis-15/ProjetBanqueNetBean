/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import entities.CompteBancaire;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


/**
 *
 * @author a.djadour
 */
@Stateless
@LocalBean
public class CompteBancaireManager {

    @PersistenceContext(unitName = "DjadourLacabanneBanque-ejbPU")
    private EntityManager em;

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    
    public void creerCompte(CompteBancaire c){
        em.persist(c);
    }
    public List<CompteBancaire> getAllComptes (){
        
        Query query = em.createNamedQuery("CompteBancaire.findAll");  
        return query.getResultList();  
        
       }
    
    public void creerComptesTest() {
        creerCompte(new CompteBancaire("John Lennon", 150000,0,true));  
        creerCompte(new CompteBancaire("Anis Djadour", 950000,2,true));  
        creerCompte(new CompteBancaire("Ringo Starr", 20000,0,true));  
        creerCompte(new CompteBancaire("Georges Harrisson", 100000,0,true));
        creerCompte(new CompteBancaire("James",15521,3,true));
    }
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    public void persist(Object object) {
        em.persist(object);
    }
    
    public CompteBancaire getCompteBancaire (long id){
        return em.find(CompteBancaire.class, id);
    }
    
    public CompteBancaire update(CompteBancaire c){
        return em.merge(c);
        
    }
   public List<CompteBancaire> getCompteBancaireByUserId(long userId, boolean h) {  
        Query query = em.createNamedQuery("CompteBancaire .findByUserId");  
        query.setParameter("userId", userId);
        query.setParameter("compteActif", h);
        return  query.getResultList();  
 } 
   
    public List<CompteBancaire> getCompteBancaireByAc(boolean m) {  
        Query query = em.createNamedQuery("CompteBancaire .findByAc");  
        query.setParameter("compteActif", m);  
        return  query.getResultList();  
 }  
    
    
}
