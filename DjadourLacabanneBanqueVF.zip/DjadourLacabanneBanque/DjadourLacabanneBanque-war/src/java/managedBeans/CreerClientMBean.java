/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managedBeans;

import entities.CompteBancaire;
import entities.Utilisateur;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import session.CompteBancaireManager;
import session.UtilisateurManager;
import managedBeans.UtilisateurMBean;
import managedBeans.CompteBancaireMBean;

/**
 *
 * @author a.djadour
 */
@Named(value = "creerClientMBean")
@ViewScoped
public class CreerClientMBean implements Serializable {

    @EJB
    private UtilisateurManager utilisateurManager;

    /**
     * Creates a new instance of CreerClientMBean
     */
    public CreerClientMBean() {
    }
    
    private CompteBancaire compteBancaire;
    private Utilisateur utilisateur;
    private String nom;
    private long id;
    private int solde;
    private long userId;
    private int montant;
    private String nomUtilisateur;
    private String password;
    
    FacesContext context;
    ExternalContext externalContext;
    Utilisateur u;

    public int getMontant() {
        return montant;
    }

    public void setMontant(int montant) {
        this.montant = montant;
    }
    

    public Utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }
    
   
    
    
    

    public String getNomUtilisateur() {
        return nomUtilisateur;
    }

    public void setNomUtilisateur(String nomUtilisateur) {
        this.nomUtilisateur = nomUtilisateur;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    

    public String getNom() {
       
        return nom;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public void setNombyid() {
        
        this.nom = nom;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getSolde() {
        return solde;
    }

    public void setSolde(int solde) {
        this.solde = solde;
    }
    @EJB
    private CompteBancaireManager compteBancaireManager;

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
    

    public CompteBancaire getCompte(){
       return compteBancaire;
   }

    public void setCompteBancaire(CompteBancaire compteBancaire) {
        this.compteBancaire = compteBancaire;
    }
    
    public String creerClient(){
       
       
        
        //compteBancaireManager.creerCompte(new CompteBancaire(nom, solde,userId));
        utilisateurManager.creerUtilisateur(new Utilisateur(nom, nomUtilisateur, password, "client", true));
        
        return "affichageClient";
    }
    
    public String voirNom(){
       
        return "CreerCompte";
    }
    
   
    
    public void creerCompteB(long id){
        
         
        Utilisateur jk = new Utilisateur();
        jk = utilisateurManager.getUtilisateur(id);
        nom = jk.getNom();
        CompteBancaire ci = new CompteBancaire(jk.getNom(),montant,id,true);
        
       
        compteBancaireManager.creerCompte(ci);
        
        
        
    }
    
    
}
