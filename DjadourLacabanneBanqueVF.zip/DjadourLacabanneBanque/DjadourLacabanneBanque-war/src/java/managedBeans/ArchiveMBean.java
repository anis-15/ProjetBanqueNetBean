/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managedBeans;

import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import session.CompteBancaireManager;
import session.UtilisateurManager;
import entities.CompteBancaire;
import entities.Utilisateur;
import entities.OperationCompte;

/**
 *
 * @author a.djadour
 */
@Named(value = "archiveMBean")
@ViewScoped
public class ArchiveMBean implements Serializable {

    @EJB
    private UtilisateurManager utilisateurManager;

    @EJB
    private CompteBancaireManager compteBancaireManager;
    
    /**
     * Creates a new instance of ArchiveMBean
     */
    private long userId;
    private long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    
    
    public ArchiveMBean() {
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }
    
    
     public List<Utilisateur> getUArchive(){
        return utilisateurManager.getUtilisateurByAc(false);
    }
     
     public List<CompteBancaire> getCompteA(){
         return compteBancaireManager.getCompteBancaireByAc(false);
     }
     
     
     
     public String getcompteCA(){
         return "ArchiveC";
     }
     
     public String getutilsateurUA(){
         return "ArchiveU";
     }
     
     public void archiveUbyId(){
         
         Utilisateur u =utilisateurManager.getUtilisateur(userId);
         u.setUtilisateurActif(false);
         utilisateurManager.update(u);
     }
     
     public void archiveCbyId(){
         CompteBancaire c = compteBancaireManager.getCompteBancaire(id);
         c.setCompteActif(false);
         compteBancaireManager.update(c);
     }
             
}
