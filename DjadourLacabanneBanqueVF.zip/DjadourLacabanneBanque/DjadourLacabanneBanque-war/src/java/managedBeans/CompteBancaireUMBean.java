/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managedBeans;

import java.util.List;
import entities.CompteBancaire;
import entities.Utilisateur;
import java.io.Serializable;
import java.util.ArrayList;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import session.CompteBancaireManager;
import session.UtilisateurManager;

/**
 *
 * @author a.djadour
 */
@Named(value = "compteBancaireUMBean")
@ViewScoped
public class CompteBancaireUMBean implements Serializable {

    @EJB
    private UtilisateurManager utilisateurManager;

    @EJB
    private CompteBancaireManager compteBancaireManager;
    
    
    
    private long userId;
    private List<CompteBancaire> listCompteBancaire;

    /**
     * Creates a new instance of CompteBancaireUMBean
     */
    
    public CompteBancaireUMBean() {
    }
    public long getUserId(){
        return userId;
    }
    
    public void setUserId(long userId){
        this.userId = userId;
    }
    
    public List<CompteBancaire> getListCompteBancaireByuserId(){
        List<CompteBancaire> l = new ArrayList<CompteBancaire>();
        
        l= compteBancaireManager.getCompteBancaireByUserId(userId, true);
        
        
        return l;
        
    }
    
    public void loadCompteBancaire(){
       this.listCompteBancaire= compteBancaireManager.getCompteBancaireByUserId(userId, true);
   }
    
    public Utilisateur getUtilisateur(){
        return utilisateurManager.getUtilisateur(userId);
    }
    
}