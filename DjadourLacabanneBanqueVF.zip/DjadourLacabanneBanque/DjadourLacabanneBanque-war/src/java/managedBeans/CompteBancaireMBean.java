/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managedBeans;

import entities.CompteBancaire;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import session.CompteBancaireManager;
import managedBeans.UtilisateurMBean;
import entities.OperationCompte;
import entities.Utilisateur;
import java.util.ArrayList;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import session.OperationManager;
import session.UtilisateurManager;

/**
 *
 * @author a.djadour
 */
@Named(value = "compteBancaireMBean")
@ViewScoped
public class CompteBancaireMBean implements Serializable {

    @EJB
    private OperationManager operationManager;

    @EJB
    private UtilisateurManager utilisateurManager;

    @EJB
    private CompteBancaireManager gcdm;
    
    
    

    private UtilisateurMBean mb;
    private String t;
    FacesContext context;
    ExternalContext externalContext;
    Utilisateur u;

    public String getT() {
        context = FacesContext.getCurrentInstance();
        externalContext = context.getExternalContext();
        u = (Utilisateur) externalContext.getSessionMap().get("utilisateurLog");
        if (u.getRoleType().equals("client")) {

            t = "./logClient.xhtml";

        } else if (u.getRoleType().equals("banquier")) {

            t = "./LogBanquier.xhtml";

        }
        return t;
    }

    public void setT(String t) {
        this.t = t;
    }

    /**
     * Creates a new instance of CompteBancaireMBean
     */
    public CompteBancaireMBean() {
    }

    public List<CompteBancaire> getCompteBancaires() {
        context = FacesContext.getCurrentInstance();
        externalContext = context.getExternalContext();
        u = (Utilisateur) externalContext.getSessionMap().get("utilisateurLog");

        List<CompteBancaire> l = new ArrayList<CompteBancaire>();

        if (u.getRoleType().equals("client")) {

            l = gcdm.getCompteBancaireByUserId(u.getId(),true);
            t = "./logClient.xhtml";

        } else if (u.getRoleType().equals("banquier")) {
            l = gcdm.getAllComptes();
            t = "./LogBanquier.xhtml";

        }

        return l;
    }

    public void insertCompte() {
        gcdm.creerComptesTest();
    }

    public String showDetails(long id) {
        context = FacesContext.getCurrentInstance();
        externalContext = context.getExternalContext();
        u = (Utilisateur) externalContext.getSessionMap().get("utilisateurLog");
        String sh = "";
        if(u.getRoleType().equals("client")){
        sh ="CompteBancaireDetail?id=" + id;
        }
        if(u.getRoleType().equals("banquier")){
        sh = "CompteBanquierDetail?id=" + id;    
        }
       
           return sh;
    }
    
   
    public List<OperationCompte> getAllOperation(){
        return operationManager.getAllOperation();
    }
}
