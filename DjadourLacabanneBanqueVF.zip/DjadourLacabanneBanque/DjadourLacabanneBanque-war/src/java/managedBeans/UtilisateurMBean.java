package managedBeans;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import entities.Utilisateur;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import session.CompteBancaireManager;
import session.UtilisateurManager;

/**
 *
 * @author a.djadour
 */
@Named(value = "utilisateurMBean")
@ViewScoped
public class UtilisateurMBean implements Serializable {

    @EJB
    private CompteBancaireManager compteBancaireManager;

    @EJB
    private UtilisateurManager utilisateurManager;
    
    

    private Utilisateur utilisateur;
    
    private String nomUtilisateur;
    private String password;
    
    
    private String t;

    public Utilisateur getUtilisateur() {
        
        FacesContext context = FacesContext.getCurrentInstance() ;  
        ExternalContext externalContext ;
        context = FacesContext.getCurrentInstance();
        externalContext = context.getExternalContext();
        utilisateur = (Utilisateur) externalContext.getSessionMap().get("utilisateurLog");
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    
    
    public String getT() {
        return t;
    }

    public void setT(String t) {
        this.t = t;
    }

    
    
     public UtilisateurMBean() {
         this.nomUtilisateur = "";
    }

    public String getNomUtilisateur() {
        return nomUtilisateur;
    }

    public void setNomUtilisateur(String nomUtilisateur) {
        this.nomUtilisateur = nomUtilisateur;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String seConnecter(){
        
       // utilisateurManager.creerUtilisateurTest();
        //compteBancaireManager.creerComptesTest();
        FacesContext context = FacesContext.getCurrentInstance() ;
        String m = "";
        
        ExternalContext externalContext ;
        externalContext = context.getExternalContext();
        
        
        
               
         utilisateur = utilisateurManager.getUtilisateurByNP(nomUtilisateur, password).get(0);
        
        
        
        
        if(utilisateur != null){
            externalContext.getSessionMap().put("utilisateurLog",utilisateur);
           
            if(utilisateur.getRoleType().equals("client")){
                m = "indexClient";
                t="./logClient.xhtml";
            }
            else if (utilisateur.getRoleType().equals("banquier")) {
                m ="indexBanquier";
                t ="./LogBanquier.xhtml";
            }
        }else{
             m = "mot de passe ou nom d'utilisateur inconnu";
        }
    
        return m;
  } 
    
    public void seDeconnecter() throws IOException{
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        externalContext.invalidateSession();
        externalContext.redirect(externalContext.getRequestContextPath() + "/faces/HomePage.xhtml");
    }
    
     public List<Utilisateur> getListUtilisateur(){
        return utilisateurManager.getUtilisateurByAcR("client", true);
                
    }
    
    
     public String showDetails(long id) {
        return "affichageCompteBanquier?id=" + id;
    }
    /**
     * Creates a new instance of UtilisateurMBean
     */
   
    
    
    
}
