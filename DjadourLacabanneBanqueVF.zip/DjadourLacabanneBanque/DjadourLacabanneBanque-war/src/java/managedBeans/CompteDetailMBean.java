/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managedBeans;

import entities.CompteBancaire;
import session.CompteBancaireManager;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import session.OperationManager;
import entities.OperationCompte;
import entities.Utilisateur;
import static java.awt.SystemColor.window;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import java.text.SimpleDateFormat;

/**
 *
 * @author a.djadour
 */
@Named(value = "compteDetailMBean")
@ViewScoped
public class CompteDetailMBean implements Serializable {

    @EJB
    private OperationManager operationManager;

    @EJB
    private CompteBancaireManager compteBancaireManager;
    
    private long id;
    private CompteBancaire compteBancaire;
    private int montantV;
    private int montantD;
    private int montantR;
    private String message;
    private long idB;
    

    public long getId() {
        return id;
       
    }
    
    public long getIdB() {
        return idB;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getMontantV() {
        return montantV;
    }

    public void setMontantV(int montantV) {
        this.montantV = montantV;
    }

    public int getMontantD() {
        return montantD;
    }

    public void setMontantD(int montantD) {
        this.montantD = montantD;
    }

    public int getMontantR() {
        return montantR;
    }

    public void setMontantR(int montantR) {
        this.montantR = montantR;
    }

   

    public void setId(long id) {
        this.id = id;
    }
    
    public void setIdB(long idb) {
        this.idB = idb;
    }
    
    public List<OperationCompte> getListOperationCompte(){
        List<OperationCompte> l = new ArrayList<OperationCompte>();
        l = operationManager.getLisOperationBycompteId(id);
        return l;
    }

    /**
     * Creates a new instance of CompteDetailMBean
     */
    
   public CompteBancaire getDetails(){
       return compteBancaire;
   }
   
   public void deposer(){
        
        Date dateo = new Date(System.currentTimeMillis());
        compteBancaire.deposer(montantD);
        compteBancaire= compteBancaireManager.update(compteBancaire);
         operationManager.creerOperation(new OperationCompte("deposer",montantD,formaterDate(dateo),id));
        
        
   }
   
   public void  retirer(){
       
        Date dateo = new Date(System.currentTimeMillis());
        int s;
        s = compteBancaire.retirer(montantR);
        if(s <0){
             message = "Illégall opération";
             
        } else {
        compteBancaire= compteBancaireManager.update(compteBancaire);
         operationManager.creerOperation(new OperationCompte("retirer",-montantR,formaterDate(dateo),id));
        
         }
   }
   
   public void loadCompteBancaire(){
       this.compteBancaire = compteBancaireManager.getCompteBancaire(id);
   }
   
   
    public CompteDetailMBean() {
    }
    
    public void virement(){
        
        Date dateo = new Date(System.currentTimeMillis());
        CompteBancaire b;
        b = compteBancaireManager.getCompteBancaire(idB);
        compteBancaire.retirer(montantV);
        b.deposer(montantV);
        compteBancaire= compteBancaireManager.update(compteBancaire);
        b= compteBancaireManager.update(b);
        operationManager.creerOperation(new OperationCompte("VirementDebiter"+idB,-montantV,formaterDate(dateo),id));
        operationManager.creerOperation(new OperationCompte("VirementCrediter"+id,montantV,formaterDate(dateo),idB));
        
       
        
        
        
    }
    
    public String formaterDate(Date date){
        SimpleDateFormat formater = new SimpleDateFormat(" dd/MM/yyyy  HH:mm:ss");
        
        return formater.format(date);
        
        
       
        
        
    }
    
    
    
}
