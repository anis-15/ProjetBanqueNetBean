package com.example.djadourlacabannemobapp.Object;

import java.util.Date;

public class OperationCompte {

    private String id;
    private String dateo;
    private String montant;
    private String compteId;
    private String typeOperation;



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDateo() {
        return dateo;
    }

    public void setDateo(String dateo) {
        this.dateo = dateo;
    }

    public String getMontant() {
        return montant;
    }

    public void setMontant(String montant) {
        this.montant = montant;
    }

    public String getCompteId() {
        return compteId;
    }

    public void setCompteId(String compteId) {
        this.compteId = compteId;
    }

    public String getTypeOperation() {
        return typeOperation;
    }

    public void setTypeOperation(String typeOperation) {
        this.typeOperation = typeOperation;
    }

    public String getDataXml(){
        String xml =

                "<operationcompte>"+
               "<compteid>"+compteId+"</compteid>"+
                "<dateo>"+dateo+"</dateo>"+
                "<id>"+id+"</id>"+
               "<montant>"+montant+"</montant>"+
           "<operationtype>"+typeOperation+"</operationtype>"+
          "</operationcompte>";

        return xml;

    }
}
