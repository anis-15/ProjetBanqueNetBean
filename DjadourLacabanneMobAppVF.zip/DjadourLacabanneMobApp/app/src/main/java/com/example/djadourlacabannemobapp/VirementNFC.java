package com.example.djadourlacabannemobapp;

import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcEvent;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.djadourlacabannemobapp.Gestion.MyHttpRequest;
import com.example.djadourlacabannemobapp.Gestion.MyHttpRequestPost;
import com.example.djadourlacabannemobapp.Gestion.MyHttpRequestPut;
import com.example.djadourlacabannemobapp.Object.CompteBancaire;
import com.example.djadourlacabannemobapp.Object.OperationCompte;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class VirementNFC extends AppCompatActivity implements NfcAdapter.OnNdefPushCompleteCallback,
        NfcAdapter.CreateNdefMessageCallback {

    //The array lists to hold our messages
    private ArrayList<String> messagesSend = new ArrayList<>();
    private ArrayList<String> messagesReceived = new ArrayList<>();

    //Text boxes to add and display our messages
    private EditText saisiMontant;
    private TextView textReceive;
    private TextView textSend;


    private NfcAdapter mNfcAdapter;

    public void addMontant(View view)
    {

        String newMessage = saisiMontant.getText().toString();
        messagesSend.add(newMessage);

        saisiMontant.setText(null);
        updateTextViews();

        Toast.makeText(this, "Montant Saisi", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNdefPushComplete(NfcEvent event) {
        //This is called when the system detects that our NdefMessage was
        //Successfully sent.
        messagesSend.clear();
        CompteBancaire cm = ((BanqueDL) getApplication()).c;
        OperationCompte o = ((BanqueDL) getApplication()).o;


        MyHttpRequestPut put =new MyHttpRequestPut();
        put.set_app(this.getApplication());
        put.execute("http://192.168.137.1:8080/BanqueWBS/webresources/service.comptebancaire/"+cm.getId(),cm.getXmldata());

        MyHttpRequestPost requester=new MyHttpRequestPost();
        requester.set_app(this.getApplication());
        requester.execute("http://192.168.137.1:8080/BanqueWBS/webresources/service.operationcompte/",o.getDataXml());

        Intent intent = new Intent(getApplicationContext(), DetailCompte.class);
        startActivity(intent);
        finish();


    }

    @Override
    public NdefMessage createNdefMessage(NfcEvent event) {
        //This will be called when another NFC capable device is detected.
        if (messagesSend.size() == 0) {
            return null;
        }
        //We'll write the createRecords() method in just a moment
        NdefRecord[] recordsToAttach = createRecords();
        //When creating an NdefMessage we need to provide an NdefRecord[]
        return new NdefMessage(recordsToAttach);
    }

    private  void updateTextViews() {

        CompteBancaire a = new CompteBancaire();
        SimpleDateFormat formater = new SimpleDateFormat(" dd/MM/yyyy  HH:mm:ss");
        ArrayList<CompteBancaire> lc = new ArrayList<CompteBancaire>();
        lc = ((BanqueDL)getApplication()).lc;


        a = ((BanqueDL) getApplication()).c;
        OperationCompte o = new OperationCompte();
        o.setCompteId(a.getId());



        String formatDate = "";
        Date dateo = new Date(System.currentTimeMillis());
        formatDate = formater.format(dateo);
        String id = new Long(dateo.getTime()).toString();
        o.setId(id);

        //textSend.setText("Messages To Send:\n");
        //Populate Our list of messages we want to send
        textSend.setText(null);
        textReceive.setText(null);
        if(messagesSend.size() > 0) {
            for (int i = 0; i < messagesSend.size(); i++) {
                textSend.append(messagesSend.get(i));

                //textSend.append("\n");
            }
            Integer solde = Integer.parseInt(a.getSolde())-Integer.valueOf(textSend.getText().toString());
            ((BanqueDL)getApplication()).c.setSolde(solde.toString());
            o.setMontant("-"+textSend.getText().toString());
            o.setTypeOperation("VirementDebit");
            o.setDateo(formatDate);

            ((BanqueDL)getApplication()).lo.add(o);
            ((BanqueDL) getApplication()).o = o;



        }

        //textReceive.setText("Messages Received:\n");
        //Populate our list of messages we have received
        if (messagesReceived.size() > 0) {
            for (int i = 0; i < messagesReceived.size(); i++) {
                textReceive.append(messagesReceived.get(i));
                //textReceive.append("\n");
            }
            Integer solde = Integer.parseInt(a.getSolde())+Integer.valueOf(textReceive.getText().toString());
            ((BanqueDL)getApplication()).c.setSolde(solde.toString());
            o.setMontant(textReceive.getText().toString());
            o.setTypeOperation("VirementCredit");
            o.setDateo(formatDate);



            ((BanqueDL)getApplication()).o = o;
            ((BanqueDL)getApplication()).lo.add(o);
        }


    }


    //Save our Array Lists of Messages for if the user navigates away
    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putStringArrayList("messagesToSend", messagesSend);
        savedInstanceState.putStringArrayList("lastMessagesReceived", messagesReceived);
    }

    //Load our Array Lists of Messages for when the user navigates back
    @Override
    public void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        messagesSend = savedInstanceState.getStringArrayList("messagesToSend");
        messagesReceived = savedInstanceState.getStringArrayList("lastMessagesReceived");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.virement);

        saisiMontant = (EditText) findViewById(R.id.MontantSaisi);
        textSend = (TextView) findViewById(R.id.textViewSend);
        textReceive = (TextView) findViewById(R.id.textViewReceive);
        Button btnAddMessage = (Button) findViewById(R.id.buttonVirement);

        btnAddMessage.setText("Add Message");
        updateTextViews();

        //Check if NFC is available on device
        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if(mNfcAdapter != null)
        {
            //This will refer back to createNdefMessage for what it will send
            mNfcAdapter.setNdefPushMessageCallback(this, this);

            //This will be called if the message is sent successfully
            mNfcAdapter.setOnNdefPushCompleteCallback(this, this);
        }
        else
        {
            Toast.makeText(this, "NFC not available on this device", Toast.LENGTH_SHORT).show();
        }
    }

    public NdefRecord[] createRecords() {
        NdefRecord[] records = new NdefRecord[messagesSend.size() + 1];
        //To Create Messages Manually if API is less than
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
            for (int i = 0; i < messagesSend.size(); i++){
                byte[] payload = messagesSend.get(i).
                        getBytes(Charset.forName("UTF-8"));
                NdefRecord record = new NdefRecord(
                        NdefRecord.TNF_WELL_KNOWN,      //Our 3-bit Type name format
                        NdefRecord.RTD_TEXT,            //Description of our payload
                        new byte[0],                    //The optional id for our Record
                        payload);                       //Our payload for the Record

                records[i] = record;
            }
        }
        //Api is high enough that we can use createMime, which is preferred.
        else {
            for (int i = 0; i < messagesSend.size(); i++){
                byte[] payload = messagesSend.get(i).
                        getBytes(Charset.forName("UTF-8"));

                NdefRecord record = NdefRecord.createMime("text/plain",payload);
                records[i] = record;
            }
        }
        records[messagesSend.size()] =
                NdefRecord.createApplicationRecord(getPackageName());
        return records;
    }

    private void handleNfcIntent(Intent NfcIntent) {
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(NfcIntent.getAction()))
        {
            Parcelable[] receivedArray = NfcIntent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);

            if(receivedArray != null) {
                messagesReceived.clear();
                NdefMessage receivedMessage = (NdefMessage) receivedArray[0];
                NdefRecord[] attachedRecords = receivedMessage.getRecords();

                for (NdefRecord record:attachedRecords) {
                    String string = new String(record.getPayload());
                    //Make sure we don't pass along our AAR (Android Application Record)
                    if (string.equals(getPackageName())) { continue; }
                    messagesReceived.add(string);
                }


                Toast.makeText(this, "Received " + messagesReceived.size() +
                        " Messages", Toast.LENGTH_LONG).show();
                updateTextViews();
                Toast.makeText(this, "Opération réussi", Toast.LENGTH_LONG).show();
                CompteBancaire c = ((BanqueDL) getApplication()).c;
                MyHttpRequestPut put =new MyHttpRequestPut();
                put.set_app(this.getApplication());
                put.execute("http://192.168.137.1:8080/BanqueWBS/webresources/service.comptebancaire/"+c.getId(),c.getXmldata());
                OperationCompte o = ((BanqueDL) getApplication()).o;

                MyHttpRequestPost requester=new MyHttpRequestPost();
                requester.set_app(this.getApplication());
                requester.execute("http://192.168.137.1:8080/BanqueWBS/webresources/service.operationcompte/",o.getDataXml());

                Intent intent = new Intent(getApplicationContext(), DetailCompte.class);
                startActivity(intent);
                finish();
            }
            else {
                Toast.makeText(this, "Received Blank Parcel", Toast.LENGTH_LONG).show();
            }
        }
    }


    @Override
    public void onNewIntent(Intent intent) {

        super.onNewIntent(intent);
        handleNfcIntent(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("TEST","App on pause");

    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        System.out.println("on Killed");
    }

    @Override
    protected void onStart() {
        super.onStart();
    }


    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
        updateTextViews();
        handleNfcIntent(getIntent());
    }

}
