package com.example.djadourlacabannemobapp.Gestion;

import android.app.Application;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MyHttpRequestPut extends AsyncTask<String, Void, String> {


    Application app;

    public void set_app(Application myapp)
    {
        app=myapp;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected String doInBackground(String... strings) {



        String dataToSend = strings[1];
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("PUT");// Mettre POST pour poster, logique
            connection.setRequestProperty("Content-Type", "application/xml");
            connection.setDoInput(true);
            connection.connect();

            Log.d("REQUESTOUTPUT", "requesting");
            byte[] b = dataToSend.getBytes();
            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(b);

            InputStream inputStream = connection.getInputStream();


            BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while ((line = rd.readLine()) != null) {
                Log.d("response : ", line);
            }

        } catch (IOException e) {
            // writing exception to log
            e.printStackTrace();
        }


        return null;


    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

    }
}
