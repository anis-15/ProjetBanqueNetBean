package com.example.djadourlacabannemobapp.Object;

public class CompteBancaire {

    private String nom;
    private String solde;
    private String id;
    private String compteActif;
    private String userId;


    public CompteBancaire() {
        this.nom="";
        this.solde="";
        this.id="";
        this.compteActif="";
        this.userId="";
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCompteActif() {
        return compteActif;
    }

    public void setCompteActif(String compteActif) {
        this.compteActif = compteActif;
    }

    public String getNom(){
        return nom;
    }

    public void setNom(String nom){
        this.nom = nom;
    }

    public String getId(){
        return id;
    }

    public void setId(String id){
        this.id = id;
    }

    public void setSolde(String solde){
        this.solde = solde;
    }

    public String getSolde(){
        return solde;
    }

    public String getXmldata(){
        String xml = "<comptebancaire>" +
                "<compteactif>"+compteActif+"</compteactif>" +
                "<compteid>"+id+"</compteid>" +
                "<nom>"+nom+"</nom>" +
                "<solde>"+solde+"</solde>" +
                "<userid>"+userId+"</userid>" +
                "</comptebancaire>";

        return xml;
    }
}

