package com.example.djadourlacabannemobapp;




import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.djadourlacabannemobapp.Gestion.MyHttpRequest;
import com.example.djadourlacabannemobapp.Gestion.MyhttpRequestCompte;
import com.example.djadourlacabannemobapp.Gestion.MyHttpRequestOperation;
import com.example.djadourlacabannemobapp.Object.CompteBancaire;
import com.example.djadourlacabannemobapp.Object.CompteBancaireAdapter;
import com.example.djadourlacabannemobapp.Object.Utilisateur;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class MainActivity extends AppCompatActivity {

    private String contentUrl;
    private String url = "http://192.168.137.1:8080/BanqueWBS/webresources/service.utilisateur";
    private String urlc = "http://192.168.137.1:8080/BanqueWBS/webresources/service.comptebancaire";
    private String urlo = "http://192.168.137.1:8080/BanqueWBS/webresources/service.operationcompte";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button bLog = findViewById(R.id.button);

        MyHttpRequest requester=new MyHttpRequest();
        requester.set_app(MainActivity.this.getApplication());
        requester.execute(url);


        MyhttpRequestCompte requesteC =new MyhttpRequestCompte();
        requesteC.set_app(MainActivity.this.getApplication());
        requesteC.execute(urlc);

        MyHttpRequestOperation requesteO =new MyHttpRequestOperation();
        requesteO.set_app(MainActivity.this.getApplication());
        requesteO.execute(urlo);


        bLog.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v)  {



               EditText editPassword = (EditText) findViewById(R.id.password);
               EditText editUsername = (EditText) findViewById(R.id.username);



               String password = editPassword.getText().toString();
               String username = editUsername.getText().toString();








               Boolean existe = false;
               if(((BanqueDL)getApplication()).lu != null) {
                   List<Utilisateur> mylist = ((BanqueDL) getApplication()).lu;
                   Utilisateur uc = new Utilisateur();
                   for (Utilisateur ul : mylist) {
                       Log.d("DJ KNOW",ul.getNomUtilisateur()+":"+ul.getPassword());

                       if (ul.getNomUtilisateur().equals(username) && ul.getPassword().equals(password) && ul.getUtilisateurActif().equals("1")) {
                           Log.d("DJ",ul.getNomUtilisateur()+":"+username);
                           Log.d("DJ",ul.getPassword()+":"+password);
                           uc  = ul;
                           ((BanqueDL) getApplication()).u = uc;

                           existe = true;

                       }
                   }

                   if (existe) {
                       Intent intent = new Intent(getApplicationContext(), ListCompte.class);
                       intent.putExtra("nomUtilisateur", username);
                       startActivity(intent);
                   } else {
                       Toast.makeText(getApplicationContext(), "erreur de login/mdp ou compte désactiver", Toast.LENGTH_LONG).show();
                   }
               }

           }
       });








    }









}
