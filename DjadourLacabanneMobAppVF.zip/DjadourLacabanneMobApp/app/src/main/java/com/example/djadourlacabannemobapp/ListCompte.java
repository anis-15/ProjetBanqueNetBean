package com.example.djadourlacabannemobapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.djadourlacabannemobapp.Object.CompteBancaire;
import com.example.djadourlacabannemobapp.Object.CompteBancaireAdapter;
import com.example.djadourlacabannemobapp.Object.Utilisateur;

import java.util.ArrayList;
import java.util.List;

public class ListCompte extends AppCompatActivity {
    ListView listView;


    ArrayList<CompteBancaire> cpts = new ArrayList<CompteBancaire>();
    ArrayList<CompteBancaire> cu = new ArrayList<CompteBancaire>();
    Utilisateur u = new Utilisateur();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_list_compte);

        //List<Utilisateur> mylist=((BanqueDL)getApplication()).lu;
        listView = (ListView) findViewById(R.id.compteBancaire_list);

        cpts = ((BanqueDL) getApplication()).lc;
        u = ((BanqueDL) getApplication()).u;

        for(CompteBancaire c : cpts){
            if(c.getUserId().equals(u.getId())){
                cu.add(c);
            }

        }

        CompteBancaireAdapter adapter = new CompteBancaireAdapter(this, cu);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CompteBancaire selectC = (CompteBancaire) parent.getItemAtPosition(position);
                ((BanqueDL)getApplication()).c = selectC;
                Intent intent = new Intent(getApplicationContext(), DetailCompte.class);
                startActivity(intent);
            }
        });







    }



}
