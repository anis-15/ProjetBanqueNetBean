package com.example.djadourlacabannemobapp.Gestion;

import android.app.Application;
import android.content.res.XmlResourceParser;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.example.djadourlacabannemobapp.BanqueDL;
import com.example.djadourlacabannemobapp.Object.CompteBancaire;
import com.example.djadourlacabannemobapp.Object.OperationCompte;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MyHttpRequestOperation extends AsyncTask<String,Void,String> {

    String contentUrlO;

    Application app;

    public void set_app(Application myapp)
    {
        app=myapp;
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected String doInBackground(String... strings) {
        Log.i("Djadour", "LAUNCHED !");
        URL url;
        HttpURLConnection urlConnection = null;


        try {


            url = new URL(strings[0]);
            urlConnection = (HttpURLConnection) url.openConnection();

            int responseCode = urlConnection.getResponseCode();

            Log.i("Djadour", "RESP CODE: ["+responseCode+"]");
            if(responseCode == HttpURLConnection.HTTP_OK){
                contentUrlO = readStream(urlConnection.getInputStream());




            }



        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        return null;
    }




    private String readStream(InputStream in) {
        BufferedReader reader = null;
        StringBuffer response = new StringBuffer();
        try {
            reader = new BufferedReader(new InputStreamReader(in));
            String line = "";
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        Log.i("Djadour", "VAL: ["+response.toString()+"]");
        return response.toString();
    }




    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onPostExecute(String s) {
        super.onPostExecute(s);


        ((BanqueDL)app).lo = ParseOperation();






    }



    public ArrayList<OperationCompte> ParseOperation(){
        ArrayList<OperationCompte> lo = new ArrayList<OperationCompte>();
        OperationCompte opt = new OperationCompte();
        InputStream fu = new ByteArrayInputStream(contentUrlO.getBytes(StandardCharsets.UTF_8));

        try {
            XmlPullParser parser;
            XmlPullParserFactory xmlFactoryObject = XmlPullParserFactory.newInstance();
            parser = xmlFactoryObject.newPullParser();
            parser.setInput(fu, null);
            while (parser.next() != XmlResourceParser.END_DOCUMENT) {


                if (parser.getEventType() == XmlResourceParser.START_TAG && parser.getName() != null) {
                    // Retrieve server URL...

                    if (parser.getName().equalsIgnoreCase("compteid")) {
                        opt = new OperationCompte();

                        parser.next();
                        opt.setCompteId(parser.getText());



                    }
                    if ( parser.getName() != null && parser.getName().equalsIgnoreCase("dateo")) {


                        parser.next();
                        String s = parser.getText();
                        opt.setDateo(s);



                    }
                    if ( parser.getName() != null && parser.getName().equalsIgnoreCase("id")) {
                        parser.next();
                        opt.setId(parser.getText());
                    }
                    if (parser.getName() != null && parser.getName().equalsIgnoreCase("montant")) {
                        parser.next();
                        opt.setMontant(parser.getText());

                    }
                    if (parser.getName() != null && parser.getName().equalsIgnoreCase("operationtype")) {
                        parser.next();
                        opt.setTypeOperation(parser.getText());
                        lo.add(opt);
                    }



                }


            }




        } catch (Exception e) {
            // !!!! xml file or attribute not found !!!
            Log.e("erreur de parsing:",e.getMessage(), e);

        }








        return lo;
    }


}
