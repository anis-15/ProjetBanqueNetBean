package com.example.djadourlacabannemobapp.Object;

import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.widget.Toast;

import com.example.djadourlacabannemobapp.R;

import java.util.List;

public class Utilisateur {

    private String id;
    private String nom;
    private String nomUtilisateur;
    private String password;
    private String roleType;
    private String utilisateurActif;

    public Utilisateur(){
        this.id="";
        this.nom="";
        this.nomUtilisateur="";
        this.password="";
        this.roleType="";
        this.utilisateurActif="";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNomUtilisateur() {
        return nomUtilisateur;
    }

    public void setNomUtilisateur(String nomUtilisateur) {
        this.nomUtilisateur = nomUtilisateur;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password){
      this.password = password;
    }

    public String getRoleType() {
        return roleType;
    }

    public void setRoleType(String roleType){

        this.roleType = roleType;

    }

    public String getUtilisateurActif() {
        return utilisateurActif;
    }

    public void setUtilisateurActif(String utilisateurActif) {
        this.utilisateurActif = utilisateurActif;
    }
}
