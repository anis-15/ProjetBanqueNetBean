package com.example.djadourlacabannemobapp;

import android.app.Application;
import android.content.res.XmlResourceParser;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.example.djadourlacabannemobapp.Object.CompteBancaire;
import com.example.djadourlacabannemobapp.Object.OperationCompte;
import com.example.djadourlacabannemobapp.Object.Utilisateur;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class BanqueDL extends Application {
    public List<Utilisateur> lu;
    public ArrayList<CompteBancaire> lc;
    public Utilisateur u;
    public CompteBancaire c;
    public ArrayList<OperationCompte> lo;
    public OperationCompte o;
}
