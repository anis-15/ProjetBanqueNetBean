package com.example.djadourlacabannemobapp.Object;

import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.widget.Toast;

import com.example.djadourlacabannemobapp.R;

import java.util.ArrayList;
import java.util.List;



public class GestionUtilisateur {
    Utilisateur u;

    public GestionUtilisateur (){
    }
}
