package com.example.djadourlacabannemobapp;

import android.app.AppComponentFactory;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.djadourlacabannemobapp.Object.CompteBancaire;
import com.example.djadourlacabannemobapp.Object.OperationCompte;
import com.example.djadourlacabannemobapp.Object.OperationCompteAdapter;

import java.util.ArrayList;

public class DetailCompte extends AppCompatActivity {

    ListView listView;
    TextView idCompte;
    TextView montant;
    Button effectuerVirement;
    Button retourMescomptes;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_compte);
        ArrayList<OperationCompte> opt = new ArrayList<OperationCompte>();
        ArrayList<OperationCompte> opti = new ArrayList<OperationCompte>();
        CompteBancaire c = new CompteBancaire();

        listView = findViewById(R.id.operation_list);
        idCompte =findViewById(R.id.textViewIdcompte);
        montant =findViewById(R.id.textViewMontant);
        effectuerVirement = findViewById(R.id.buttonVirement);
        retourMescomptes = findViewById(R.id.buttonMesComptes);

              opt=((BanqueDL)getApplication()).lo;
              c = ((BanqueDL)getApplication()).c;

              idCompte.setText(c.getId());
              montant.setText(c.getSolde()+" €");

              for( OperationCompte op : opt){
                  if(op.getCompteId().equals(c.getId())){
                      opti.add(op);
                  }
              }

        OperationCompteAdapter adapter = new OperationCompteAdapter(this, opti);

              listView.setAdapter(adapter);

              effectuerVirement.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {

                      Intent intent = new Intent(getApplicationContext(), VirementNFC.class);
                      startActivity(intent);

                  }
              });

              retourMescomptes.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                      Intent intent = new Intent(getApplicationContext(), ListCompte.class);
                      startActivity(intent);
                  }
              });






    }
}
