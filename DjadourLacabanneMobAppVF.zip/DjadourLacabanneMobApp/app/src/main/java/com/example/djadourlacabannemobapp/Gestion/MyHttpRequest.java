package com.example.djadourlacabannemobapp.Gestion;

import android.app.Application;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;


import androidx.annotation.RequiresApi;

import com.example.djadourlacabannemobapp.BanqueDL;
import com.example.djadourlacabannemobapp.Object.CompteBancaire;
import com.example.djadourlacabannemobapp.Object.CompteBancaireAdapter;
import com.example.djadourlacabannemobapp.Object.Utilisateur;
import com.example.djadourlacabannemobapp.R;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


public class MyHttpRequest extends AsyncTask<String,Void,String> {

    String contentUrlU;
    Application app;

    public void set_app(Application myapp)
    {
        app=myapp;
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected String doInBackground(String... strings) {

        URL url;
        HttpURLConnection urlConnection = null;


        try {


            url = new URL(strings[0]);
            urlConnection = (HttpURLConnection) url.openConnection();

            int responseCode = urlConnection.getResponseCode();

            if(responseCode == HttpURLConnection.HTTP_OK){
                contentUrlU = readStream(urlConnection.getInputStream());




            }



        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        return null;
    }




    private String readStream(InputStream in) {
        BufferedReader reader = null;
        StringBuffer response = new StringBuffer();
        try {
            reader = new BufferedReader(new InputStreamReader(in));
            String line = "";
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        Log.i("Djadour", "VAL: ["+response.toString()+"]");
        return response.toString();
    }




    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onPostExecute(String s) {
        super.onPostExecute(s);


                ((BanqueDL)app).lu= ParseUtilisateur();







    }

    public List<Utilisateur> ParseUtilisateur() {

        List<Utilisateur> lu = new ArrayList<Utilisateur>();

        Utilisateur u = null;
        InputStream fu = new ByteArrayInputStream(contentUrlU.getBytes(StandardCharsets.UTF_8));



        try {

            XmlPullParser parser;
            XmlPullParserFactory xmlFactoryObject = XmlPullParserFactory.newInstance();
            parser = xmlFactoryObject.newPullParser();
            parser.setInput(fu, null);


            while (parser.next() != XmlResourceParser.END_DOCUMENT) {

                Log.e("Djadour", "VALXML:["+parser.getName()+"]");
                if (parser.getEventType() == XmlResourceParser.START_TAG && parser.getName() != null) {
                    // Retrieve server URL...
                    if (parser.getName().equalsIgnoreCase("id")) {
                        u = new Utilisateur();

                        parser.next();
                        u.setId(parser.getText());


                    }
                    if (parser.getName() != null && parser.getName().equalsIgnoreCase("nom")) {
                        parser.next();
                        u.setNom(parser.getText());
                    }
                    if (parser.getName() != null && parser.getName().equalsIgnoreCase("nomutilisateur")) {
                        parser.next();
                        u.setNomUtilisateur(parser.getText());
                    }

                    if (parser.getName() != null && parser.getName().equalsIgnoreCase("password")) {
                        parser.next();
                        u.setPassword(parser.getText());
                    }
                    if (parser.getName() != null && parser.getName().equalsIgnoreCase("roletype")) {
                        parser.next();
                        u.setRoleType(parser.getText());




                    }

                    if (parser.getName() != null && parser.getName().equalsIgnoreCase("utilisateurActif")) {
                        parser.next();
                        u.setUtilisateurActif(parser.getText());
                        lu.add(u);
                    }


                }


            }






        } catch (Exception e) {
            // !!!! xml file or attribute not found !!!
            Log.e("erreur de parsing:", e.getMessage());
            // Toast.makeText(this, "AN ERROR OCCURED DURING XML PARSING! " + e.getMessage(), Toast.LENGTH_LONG).show();


        }

        return lu;

    }


    }







