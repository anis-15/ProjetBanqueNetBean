package com.example.djadourlacabannemobapp.Object;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.djadourlacabannemobapp.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OperationCompteAdapter extends ArrayAdapter<OperationCompte> {

    private Context mContext;
    private List<OperationCompte> opct = new ArrayList<>();

    public OperationCompteAdapter(@NonNull Context context, @SuppressLint("SupportAnnotationUsage") @LayoutRes ArrayList<OperationCompte> list) {
        super(context, 0 , list);
        mContext = context;
        opct = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(mContext).inflate(R.layout.list_operation,parent,false);

        OperationCompte opt = opct.get(position);



        SimpleDateFormat formater = new SimpleDateFormat(" dd/MM/yyyy  HH:mm:ss");



        TextView montant = (TextView) listItem.findViewById(R.id.textView_montant);
        montant.setText(opt.getMontant()+" €");

        TextView dateo = (TextView) listItem.findViewById(R.id.textView_dateo);
        dateo.setText(opt.getDateo());

        TextView typeOperation = (TextView) listItem.findViewById(R.id.textView_typeOperation);
        typeOperation.setText(opt.getTypeOperation());

        return listItem;
    }

}
